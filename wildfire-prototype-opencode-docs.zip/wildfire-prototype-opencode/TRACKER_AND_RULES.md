# Live Tracker & Agent Rules

## Progress tracker
| Phase | Status | Evidence |
|---|---|---|
| 0. Artifact audit | NOT STARTED | Find shards, checkpoints, architecture, preprocessing |
| 1. Sample index + loader | NOT STARTED | Stable IDs and deterministic lookup |
| 2. Preprocessing parity | NOT STARTED | Match training pipeline |
| 3. Inference API | NOT STARTED | Actual M1/M2/M3 checkpoints and masked metrics |
| 4. Frontend | NOT STARTED | Selector and comparison dashboard |
| 5. Validation + handoff | NOT STARTED | Notebook parity and setup docs |

Update this table after every work session.

## Non-negotiable rules
1. Inspect repository and artifacts before coding.
2. Never invent paths, checkpoint names, feature values, normalization constants, or metadata.
3. Do not retrain models unless explicitly requested.
4. Do not alter architecture to force checkpoint loading; use the architecture compatible with the checkpoints.
5. Do not silently change feature order or preprocessing.
6. Do not infer date, geography, event, or chronology from sample IDs.
7. Exclude target `-1` pixels from metrics; never count them as non-fire.
8. Map unknown previous-mask inputs to 0 only if that matches training.
9. Never tune thresholds on test data.
10. Keep dataset/checkpoints out of Git.
11. Avoid database, auth, Docker, cloud deployment, and unrelated infrastructure unless justified and approved.
12. Make small, testable changes; do not rewrite working components wholesale.
13. Run tests and report actual results. Never claim unrun tests passed.
14. If a required artifact is missing, stop and report exactly what is missing. Never substitute a mock model as real inference.
15. Keep partial model failures explicit.
16. Trace every result to sample ID, checkpoint, preprocessing version, and threshold.

## OpenCode protocol
First read all docs, inspect repository/environment/artifacts, then produce an artifact inventory with exact paths and sizes. Report blockers before implementation. Follow phases in order. At each milestone report changed files, commands, actual test results, remaining blockers, and tracker status.

## Definition of done
A user selects a stable sample ID, runs all three actual trained checkpoints, views comparable prediction masks, and sees correctly masked metrics where ground truth is valid. Results are reproducible and clearly labeled as research outputs, not operational forecasts.
